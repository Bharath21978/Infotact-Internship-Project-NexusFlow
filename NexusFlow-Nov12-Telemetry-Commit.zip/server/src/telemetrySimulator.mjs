/**
 * NexusFlow - simulated IoT telemetry source.
 * Runs without physical sensors or third-party packages.
 *
 * Usage:
 *   node server/src/telemetrySimulator.mjs         # one sample batch
 *   node server/src/telemetrySimulator.mjs --watch # new batch every 2 seconds
 */
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

export const DEVICES = Object.freeze([
  { id: 'sensor-temp-01', name: 'Boiler Temperature', metric: 'temperature', unit: '°C', min: 20, max: 45, alertAbove: 38 },
  { id: 'sensor-humidity-01', name: 'Warehouse Humidity', metric: 'humidity', unit: '%', min: 25, max: 85, alertBelow: 35 },
  { id: 'sensor-pressure-01', name: 'Pipe Pressure', metric: 'pressure', unit: 'hPa', min: 980, max: 1050, alertAbove: 1035 },
  { id: 'sensor-vibration-01', name: 'Motor Vibration', metric: 'vibration', unit: 'mm/s', min: 0.1, max: 1.8, alertAbove: 1.4 },
]);

/** Create a bounded reading and evaluate its alert threshold. */
export function generateReading(device, random = Math.random, timestamp = new Date()) {
  if (!device || !Number.isFinite(device.min) || !Number.isFinite(device.max) || device.max < device.min) {
    throw new TypeError('A device must have valid min/max bounds');
  }
  const fraction = random();
  if (!Number.isFinite(fraction) || fraction < 0 || fraction >= 1) {
    throw new RangeError('Random source must return a value in [0, 1)');
  }
  const value = Number((device.min + fraction * (device.max - device.min)).toFixed(2));
  const breached =
    (Number.isFinite(device.alertAbove) && value > device.alertAbove) ||
    (Number.isFinite(device.alertBelow) && value < device.alertBelow);

  return {
    deviceId: device.id,
    deviceName: device.name,
    metric: device.metric,
    value,
    unit: device.unit,
    timestamp: timestamp.toISOString(),
    status: breached ? 'ALERT' : 'NORMAL',
  };
}

/** Shared batch format for a future API endpoint or Socket.IO event. */
export function generateBatch(random = Math.random, timestamp = new Date()) {
  return DEVICES.map((device) => generateReading(device, random, timestamp));
}

// Stand-alone smoke test / demo, without requiring Express or the database.
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const printBatch = () => console.log(JSON.stringify({ event: 'telemetry:update', readings: generateBatch() }, null, 2));
  printBatch();
  if (process.argv.includes('--watch')) {
    setInterval(printBatch, 2000);
  }
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { DEVICES, generateBatch, generateReading } from '../src/telemetrySimulator.mjs';

test('generates a time-stamped reading for each simulated device', () => {
  const now = new Date('2026-11-12T12:00:00.000Z');
  const batch = generateBatch(() => 0.5, now);
  assert.equal(batch.length, DEVICES.length);
  for (const [index, reading] of batch.entries()) {
    assert.equal(reading.deviceId, DEVICES[index].id);
    assert.equal(reading.timestamp, now.toISOString());
    assert.ok(reading.value >= DEVICES[index].min);
    assert.ok(reading.value <= DEVICES[index].max);
  }
});

test('flags readings above an upper limit', () => {
  const reading = generateReading(DEVICES[0], () => 0.99);
  assert.equal(reading.status, 'ALERT');
});

test('flags readings below a lower limit', () => {
  const reading = generateReading(DEVICES[1], () => 0.01);
  assert.equal(reading.status, 'ALERT');
});

test('keeps readings within thresholds normal', () => {
  const reading = generateReading(DEVICES[0], () => 0.5);
  assert.equal(reading.status, 'NORMAL');
});

test('rejects invalid random values', () => {
  assert.throws(() => generateReading(DEVICES[0], () => 1), RangeError);
});
